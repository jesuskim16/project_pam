package com.example;

public interface IHelloWorld {
	public void sayHello();
	public void myHello();
}
