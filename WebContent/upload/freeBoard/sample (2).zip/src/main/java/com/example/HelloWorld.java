package com.example;

public class HelloWorld implements IHelloWorld {
	private String name;

	public void setName(String name) {
		this.name = name;
	}
	
	public void sayHello() {
		System.out.println("Hello " + this.name);
	}

	@Override
	public void myHello() {
		System.out.println("My " + this.name);
		
	}
}
